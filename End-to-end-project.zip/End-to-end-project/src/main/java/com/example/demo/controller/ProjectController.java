package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Comments;
import com.example.demo.entity.Genre;
import com.example.demo.entity.Likes;
import com.example.demo.entity.Users;
import com.example.demo.entity.Video;
import com.example.demo.service.CommentsService;
import com.example.demo.service.GenreService;
import com.example.demo.service.KafkaProducer;
import com.example.demo.service.LikesService;
import com.example.demo.service.UserService;
import com.example.demo.service.VideoService;

@RestController
public class ProjectController {
	
	@Autowired
	GenreService gs;
	
	@Autowired
	UserService us;
	
	@Autowired
	VideoService vs;
	
	@Autowired
	LikesService ls;
	
	@Autowired
	CommentsService cs;
	
	@Autowired
	KafkaProducer kp;
	
	@PostMapping(path="/api/users")
	public ResponseEntity<Users> addUser(@RequestBody Users user)
	{
		us.addUser(user);
		return new ResponseEntity<>(user,HttpStatus.CREATED);
		
	}
	
	@GetMapping("/api/genres")
	public ResponseEntity<List<Genre>> getAllGenres()
	{
		List<Genre> genres = gs.getGenres();
		return new ResponseEntity<>(genres,HttpStatus.OK);
	}
	
	@PostMapping("/api/{userId}/genres")
	public ResponseEntity<String> addGenre(@PathVariable("userId") int id, @RequestBody Genre genre)
	{
		Users user = us.getUser(id);
//		System.out.println(user.getUserName()+ " "+user.getRole());
		gs.AddGenre(genre);
		if(user.getRole().equalsIgnoreCase("ADMIN"))
		{
			return new ResponseEntity<>("Created succesfully with genre id "+genre.getId()+" and description is "+genre.getDescription(), HttpStatus.CREATED);
		}
		return new ResponseEntity<>("Genre cannot be created, u are not an admin",HttpStatus.CREATED);
		
	}
	
	@PutMapping("/api/{userId}/genres/{genreId}")
	public ResponseEntity<String> updateGenre(@PathVariable("userId")int userId,@PathVariable("genreId") int genreId, @RequestBody Genre genre)
	{
		Users user = us.getUser(userId);
		Genre g = gs.updateGenre(genre,genreId);
		if(user.getRole().equalsIgnoreCase("ADMIN"))
		{
			String td = user.getUserName()+" has updated a genre and genre title is: "+ genre.getName();
			kp.sendDataToGenreUpdatesTopic(td);
			return new ResponseEntity<>("Updated genre with genre id "+g.getId()+" and description is"+g.getDescription(), HttpStatus.OK);
		}
		return new ResponseEntity<>("Cannot be updated, your are not an admin",HttpStatus.OK);
	}
	
	@DeleteMapping("/api/{userId}/genres/{genreId}")
	public ResponseEntity<String> deleteGenre(@PathVariable("userId")int userId,@PathVariable("genreId") int genreId)
	{
		gs.DeleteGenre(genreId);
		Users user = us.getUser(userId);
		if(user.getRole().equalsIgnoreCase("ADMIN"))
		{
			return new ResponseEntity<>("Deleted succesfully",HttpStatus.OK);
		}
		return new ResponseEntity<>("Cannot be deleted, your are not admin",HttpStatus.OK);
	}
	
	@PostMapping("/api/{userId}/videos")
	public ResponseEntity<String> addVideo(@PathVariable("userId")int userId, @RequestBody Video video)
	{
		Users user = us.getUser(userId);
		vs.addVideoService(video);
		if(user.getRole().equalsIgnoreCase("ADMIN"))
		{
			String td = user.getUserName()+" has uploaded a new video titled: "+ video.getTitle();
			kp.sendDataToVideoUploadsTopic(td);
			return new ResponseEntity<>("A new video has been uploaded with "+video.getId()+" and title is "+video.getTitle(), HttpStatus.OK);
		}
		return new ResponseEntity<>("Cannot be uploaded, your are not an admin",HttpStatus.OK);
	}
	
	@GetMapping("/api/videos/{videoId}")
	public String getVideo(@PathVariable("videoId") int videoId, Model m)
	{
		Video v = vs.getVideoService(videoId);
//		System.out.println("video link:"+ v.getUrl());
		m.addAttribute("video", v.getUrl());
		return "displayVideo";
	}
	
	@GetMapping("/api/videos")
	public String getAllVideo(Model m)
	{
		List<Video> v = vs.getAllVideoService();
		m.addAttribute("videos", v);
		return "displayVideos";
	}
	
	@GetMapping("/api/genres/{genreId}/videos")
	public String getVideoGenre(@PathVariable("genreId")int genreId,Model m)
	{
		List<Video> v = vs.getVideoGenreService(genreId);
		m.addAttribute("videos", v);
		return "genreVideos";
	}
	
	@PutMapping("/api/{userId}/videos/{videoId}")
	public ResponseEntity<Video> updateVideo(@PathVariable("videoId") int videoId,@RequestBody Video video, @PathVariable("userId") int userId)
	{
		Users user = us.getUser(userId);
		Video v = new Video();
		
		if(user.getRole().equalsIgnoreCase("ADMIN")) 
		{
			v = vs.updateVideoService(videoId,video);
		}
		return new ResponseEntity<>(v,HttpStatus.OK);
		
	}
	
	@DeleteMapping("/api/{userId}/videos/{videoId}")
	public ResponseEntity<Video> deleteVideo(@PathVariable("videoId") int videoId, @PathVariable("userId") int userId)
	{
		Users user = us.getUser(userId);
		Video v = new Video(); 
				
		
		if(user.getRole().equalsIgnoreCase("ADMIN")) 
		{
			v = vs.deleteVideoService(videoId);
		}
		
		return new ResponseEntity<>(v,HttpStatus.OK);
	}
	
	@PostMapping("/api/{userId}/{videoId}/likes")
	public ResponseEntity<Likes> addLike(@PathVariable("videoId") int videoId, @PathVariable("userId") int userId, @RequestBody Likes like)
	{
		
		Users user = us.getUser(userId);
		Video v = vs.getVideoService(videoId);
		
		Likes l=  ls.addLikeService(v,user, like);
		String td = user.getUserName() + "liked " + v.getTitle() +"video";
		
		kp.sendDataToLikesTopic(td);
		
		return new ResponseEntity<Likes>(l,HttpStatus.OK);
	}
	
	@PostMapping("/api/{userId}/{videoId}/comments")
	public ResponseEntity<Comments> addComment(@PathVariable("videoId") int videoId, @PathVariable("userId") int userId, @RequestBody Comments comment)
	{
		
		Users user = us.getUser(userId);
		Video v = vs.getVideoService(videoId);
		String td = user.getUserName() + "Commented " + v.getTitle() +"video";
		
		Comments c = cs.addComment(v,user,comment);
		
		kp.sendDataToCommentsTopic(td);
		return new ResponseEntity<Comments>(c, HttpStatus.OK);
		
		
	}
	
	
	

}
