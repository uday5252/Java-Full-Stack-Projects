package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Users;
import com.example.demo.repository.UserRepositoryInterface;

@Service
public class UserService {
	
	@Autowired
	UserRepositoryInterface uri;

	public Users getUser(int id) {
		// TODO Auto-generated method stub
		return uri.findById(id).get();
	}

	public void addUser(Users user) {
//		 TODO Auto-generated method stub
		uri.save(user);
		
	}

}
