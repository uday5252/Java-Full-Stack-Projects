package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Likes;
import com.example.demo.entity.Users;
import com.example.demo.entity.Video;
import com.example.demo.repository.LikesRepositoryInterface;
import com.example.demo.repository.UserRepositoryInterface;
import com.example.demo.repository.VideoRepositoryInterface;

@Service
public class LikesService {
	
	@Autowired
	LikesRepositoryInterface lri;
	
	@Autowired
	VideoRepositoryInterface vri;
	
	@Autowired
	UserRepositoryInterface uri;

	public Likes addLikeService(Video v, Users user,Likes like) {
		// TODO Auto-generated method stub
	
		like.setUser(user);
		like.setVideo(v);
		lri.save(like);
		return like;
		
		
	}

}
