package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Likes {
	
	@Id
	private int Id;
	
	@ManyToOne
	Video video;
	
	@ManyToOne
	Users user;

	public Likes(int id, Video video, Users user) {
		super();
		Id = id;
		this.video = video;
		this.user = user;
	}

	public Likes() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public Video getVideo() {
		return video;
	}

	public void setVideo(Video video) {
		this.video = video;
	}

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}
	
	
	

}
