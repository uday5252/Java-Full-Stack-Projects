package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.demo.service.VideoStreamService;

import reactor.core.publisher.Mono;

@Controller
public class VideoController {
	
	@Autowired
	VideoStreamService videoService;
	
	@GetMapping(value ="/video/{videoname}", produces = "video/mp4")
	public Mono<Resource> video(@PathVariable("videoname") String vname, Model m)
	{
		Mono<Resource> receivedVideo =  videoService.readVideo(vname);
		return receivedVideo;
	}
	
	@GetMapping(value ="/video/{videoname}")
	public String video2(@PathVariable("videoname") String vname, Model m)
	{
		System.out.println(vname);
		Mono<Resource> receivedVideo =  videoService.readVideo(vname);
		m.addAttribute("video", receivedVideo);
		return "displayvideo";
	}
}
