package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Genre {
	
	@Id
	private int id;
	private String description;
	private String name;
	
	public Genre() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Genre(int id, String description,String name) {
		super();
		this.id = id;
		this.description = description;
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
