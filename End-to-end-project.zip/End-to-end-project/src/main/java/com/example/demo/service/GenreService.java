package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Genre;
import com.example.demo.repository.GenreRepositoryInterface;

@Service
public class GenreService {
	
	@Autowired
	GenreRepositoryInterface gri;

	public List<Genre> getGenres() {
		// TODO Auto-generated method stub
		return gri.findAll();
//		return null;
	}
	
	public Genre updateGenre(Genre genre,int genreId)
	{
		Genre g = gri.findById(genreId).get();
		g.setDescription(genre.getDescription()!=null?genre.getDescription():g.getDescription());
		g.setId(genre.getId()!=0?genre.getId():g.getId());
		g.setName(genre.getName()!=null?genre.getName():g.getName());
		
		gri.save(g);
		return g;
		
	}

	public void DeleteGenre(int genreId) {
		// TODO Auto-generated method stub
		gri.deleteById(genreId);
		
	}

	public void AddGenre(Genre genre) {
		// TODO Auto-generated method stub
		gri.save(genre);
		
	}

}
