package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Comments {
	
	@Id
	private int Id;
	
	@ManyToOne
	Video video;
	
	@ManyToOne
	Users user;

	private String comment;
	
	public Comments() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Comments(int id, Video video, Users user,String comment) {
		super();
		Id = id;
		this.video = video;
		this.user = user;
		this.comment = comment;
	}
	
	

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public Video getVideo() {
		return video;
	}

	public void setVideo(Video video) {
		this.video = video;
	}

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}
}
