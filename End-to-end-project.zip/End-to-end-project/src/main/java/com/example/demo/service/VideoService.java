package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Video;
import com.example.demo.repository.VideoRepositoryInterface;

@Service
public class VideoService {
	
	@Autowired
	VideoRepositoryInterface vri;

	public void addVideoService(Video video) 
	{
		vri.save(video);	
	}

	public Video getVideoService(int videoId) 
	{
		return vri.findById(videoId).get();
	}

	public List<Video> getAllVideoService() 
	{
		return vri.findAll();
	}

	public List<Video> getVideoGenreService(int genreId) 
	{
		return vri.findByGenreId(genreId);
	}

	public Video updateVideoService(int videoId,Video video) 
	{
		Video v = vri.findById(videoId).get();
		
		v.setDescription(video.getDescription()==null?v.getDescription():video.getDescription());
		v.setGenre_id(video.getGenre_id()==0?v.getGenre_id():video.getGenre_id());
		v.setId(video.getId()==0?v.getId():video.getId());
		v.setTitle(video.getTitle()==null?v.getTitle():video.getTitle());
		v.setUploadedBy(video.getUploadedBy()==null?v.getUploadedBy():video.getUploadedBy());
		v.setUrl(video.getUrl()==null?v.getUrl():video.getUrl());
		
		vri.save(v);
		return v;

	}

	public Video deleteVideoService(int videoId) 
	{
		Video v =vri.findById(videoId).get();
		vri.deleteById(videoId);
		return v;
	}

}
