package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class KafkaProducer {
	
	@Autowired
	KafkaTemplate<Integer,String> kt;
	
	public void sendDataToLikesTopic(String message) 
	{
		kt.send("user_likes",message);
	}
	
	public void sendDataToCommentsTopic(String message)
	{
		kt.send("user_comments",message);
	}
	public void sendDataToVideoUploadsTopic(String message) 
	{
		kt.send("video_uploads",message);
	}
	
	public void sendDataToGenreUpdatesTopic(String message)
	{
		kt.send("genre_updates",message);
	}
}
