package com.example.demo.entity;

import java.time.Instant;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Video {
	
	@Id
	private int id;
	private String title;
	private String description;
	private String url;
	
	private int genre_id;
	
	private String uploadedBy;
	
	@CreationTimestamp
	private Instant uploaded_at;

	public Video() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Video(int id, String title, String description, String url, int genre_id, String uploadedBy) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.url = url;
		this.genre_id = genre_id;
		this.uploadedBy = uploadedBy;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public int getGenre_id() {
		return genre_id;
	}

	public void setGenre_id(int genre_id) {
		this.genre_id = genre_id;
	}

	public String getUploadedBy() {
		return uploadedBy;
	}

	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}

	public Instant getUploaded_at() {
		return uploaded_at;
	}

	public void setUploaded_at(Instant uploaded_at) {
		this.uploaded_at = uploaded_at;
	}
	
	

}
