package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import reactor.core.publisher.Mono;

@Service
public class VideoStreamService {

	@Autowired
	ResourceLoader loader;
	
	public Mono<Resource> readVideo(String videoName) {
		// TODO Auto-generated method stub
		return Mono.fromSupplier(() -> 
		{
			return loader.getResource("classpath:videos/"+videoName+".mp4");
		});
		
	}

}
