package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.Genre;

public interface GenreRepositoryInterface extends JpaRepository<Genre,Integer>{
	

}
