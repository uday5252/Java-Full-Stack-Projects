package com.zee.demo.FinalProject.Controller;

import com.zee.demo.FinalProject.Entity.Likes;
import com.zee.demo.FinalProject.Service.LikesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController
public class LikesController
{
    @Autowired
    LikesService LS;

    @GetMapping("/likes/users/{userId}")
    public ResponseEntity<List<Likes>> getLikesByUser(@PathVariable("userId") int userid)
    {
        List<Likes> list = LS.getLikesByUserService(userid);
        return new ResponseEntity<>(list, HttpStatus.OK);
    }

    @GetMapping("/likes/videos/{videoId}")
    public ResponseEntity<List<Likes>> getLikesOfVideos(@PathVariable("videoId") int videoid)
    {
        List<Likes> list =  LS.getLikesOfVideosService(videoid);
        return new ResponseEntity<>(list, HttpStatus.OK);
    }

    @PostMapping("/likes/{userId}")
    public ResponseEntity<String> likeByUser(@PathVariable("userId") int userid,@RequestBody Likes like)
    {
        LS.likeByUserService(like,userid);
        return new ResponseEntity<>("Liked!",HttpStatus.OK);
    }

    @DeleteMapping("/likes/{userId}/{videoId}")
    public ResponseEntity<String> deleteLike(@PathVariable("userId") int userid,@PathVariable("videoId") int videoid)
    {
        LS.deleteLikeService(userid,videoid);
        return new ResponseEntity<>("Deleted!",HttpStatus.OK);
    }


}
