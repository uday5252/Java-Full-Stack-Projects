package com.zee.demo.FinalProject.Controller;

import com.zee.demo.FinalProject.Entity.Comments;
import com.zee.demo.FinalProject.Service.CommentsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CommentsController
{
    @Autowired
    CommentsService CS;

    @GetMapping("/comments/users/{userId}")
    public ResponseEntity<List<Comments>> getCommentsByUser(@PathVariable("userId") int userid)
    {
        List<Comments> list = CS.getCommentsByUserService(userid);
        return new ResponseEntity<>(list, HttpStatus.OK);
    }

    @GetMapping("/comments/videos/{videoId}")
    public ResponseEntity<List<Comments>> getCommentsOfVideos(@PathVariable("videoId") int videoid)
    {
        List<Comments> list =  CS.getCommentsOfVideosServie(videoid);
        return new ResponseEntity<>(list, HttpStatus.OK);
    }

    @PostMapping("/comments/{userId}")
    public ResponseEntity<String> commentByUser(@PathVariable("userId") int userid,@RequestBody Comments comment)
    {
        CS.commentByUserService(comment,userid);
        return new ResponseEntity<>("Commented!",HttpStatus.OK);
    }

    @DeleteMapping("/comments/{userId}/{videoId}")
    public ResponseEntity<String> deleteComment(@PathVariable("userId") int userid,@PathVariable("videoId") int videoid)
    {
        CS.deleteCommentService(userid,videoid);
        return new ResponseEntity<>("Deleted!",HttpStatus.OK);
    }

}
