package com.zee.demo.FinalProject.Repository;

import com.zee.demo.FinalProject.Entity.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UsersRepository extends JpaRepository<Users,Integer>
{
}
