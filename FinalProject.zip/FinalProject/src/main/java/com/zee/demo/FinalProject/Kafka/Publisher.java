package com.zee.demo.FinalProject.Kafka;

import org.apache.kafka.common.metrics.internals.IntGaugeSuite;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class Publisher
{
    @Autowired
    KafkaTemplate<Integer,String> KT;

    public void sendLikesInfo(String message)
    {
        KT.send("likeTopic",message);
    }

    public void sendCommentsInfo(String message)
    {
        KT.send("commentTopic",message);
    }
    public void sendVideosInfo(String message)
    {
        KT.send("videoTopic",message);
    }
    public void sendGenresInfo(String message)
    {
        KT.send("genreTopic",message);
    }
}
