package com.zee.demo.FinalProject.VideoStreaming;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class ReadVideoService
{
//    @Autowired
//    ResourceLoader loader;
//
//    public Mono<Resource> readVideoService(String videoName)
//    {
//        return Mono.fromSupplier(()->
//        {
//            return loader.getResource("classpath:videos/" + videoName + ".mp4");
//        });
//    }
}
