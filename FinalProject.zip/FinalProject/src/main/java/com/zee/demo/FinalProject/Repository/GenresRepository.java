package com.zee.demo.FinalProject.Repository;

import com.zee.demo.FinalProject.Entity.Genres;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface GenresRepository extends JpaRepository<Genres,Integer>
{
    public List<Genres> findByGenreName(String genreName);
    public List<Genres> findByGenreCode(int genreCode);

}
