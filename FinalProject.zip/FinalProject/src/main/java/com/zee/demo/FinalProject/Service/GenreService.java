package com.zee.demo.FinalProject.Service;

import com.zee.demo.FinalProject.Entity.Genres;
import com.zee.demo.FinalProject.Kafka.Publisher;
import com.zee.demo.FinalProject.Repository.GenresRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class GenreService {

    @Autowired
    Publisher P;

    @Autowired
    GenresRepository GR;
    public List<Genres> getAllGenresService()
    {
        List<Genres> genreList =GR.findAll();
//        P.sendGenresInfo("Count of genres: " + genreList.size());
        return genreList;
    }

    public void addGenreService(Genres G,String genreType)
    {
        G.setGenreName(genreType);
        P.sendGenresInfo("A new genre added " + G.getGenreName());
        GR.save(G);
    }

    public void updateGenreService(Genres G,int Id)
    {
        Genres obj = GR.findById(Id).get();
        obj.setGenreName(G.getGenreName());
        obj.setGenreDescription(G.getGenreDescription());
        P.sendGenresInfo("Genre " + G.getGenreName() + "got updated!");
        GR.save(obj);
    }

    public void deleteGenreService(int id)
    {
        GR.deleteById(id);
        P.sendGenresInfo("Genre with " + id + "is deleted!");
    }
}
