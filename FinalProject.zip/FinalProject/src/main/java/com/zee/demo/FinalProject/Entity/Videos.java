package com.zee.demo.FinalProject.Entity;

import jakarta.persistence.*;

import java.util.*;

// mp4 links
/*
http://techslides.com/demos/sample-videos/small.mp4
https://www.dropbox.com/s/df2d2gf1dvnr5uj/Sample_1280x720_mp4.mp4
https://www.dropbox.com/s/y0ry2w3i7q59ozx/Sample_854x480.mp4
 */
@Entity
public class Videos
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int videoId;
    private String videoTitle;
    private String videoDescription;
    private String videoURL;

//    @OneToMany(targetEntity = Genres.class,cascade = CascadeType.ALL)
//    @JoinColumn(name = "videoId",referencedColumnName = "videoId")
//    @OneToMany(mappedBy =
//    "video",cascade = CascadeType.ALL)
    @OneToMany(cascade = CascadeType.ALL)
    private List<Genres> genresSet;

    private String videoUploadedAt;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "videoUploadedBy")
    private Users user;

    public int getVideoId() {
        return videoId;
    }

    public String getVideoTitle() {
        return videoTitle;
    }

    public void setVideoTitle(String videoTitle) {
        this.videoTitle = videoTitle;
    }

    public String getVideoDescription() {
        return videoDescription;
    }

    public void setVideoDescription(String videoDescription) {
        this.videoDescription = videoDescription;
    }

    public String getVideoURL() {
        return videoURL;
    }

    public void setVideoURL(String videoURL) {
        this.videoURL = videoURL;
    }

    public List<Genres> getGenresSet() {
        return genresSet;
    }

    public void setGenresSet(List<Genres> genresSet) {
        this.genresSet = genresSet;
    }

    public Users getUser() {
        return user;
    }

    public void setUser(Users user) {
        this.user = user;
    }

    public String getVideoUploadedAt() {
        return videoUploadedAt;
    }

    public void setVideoUploadedAt(String videoUploadedAt) {
        this.videoUploadedAt = videoUploadedAt;
    }

    //FOR LIKE AND COMMENTS TABLES

//    @OneToMany(mappedBy = "videos")
//    private List<Likes> likesList;
//
//    @OneToMany(mappedBy = "videos")
//    private List<Comments> commentsList;
//
//    public List<Likes> getLikesList() {
//        return likesList;
//    }
//
//    public void setLikesList(List<Likes> likesList) {
//        this.likesList = likesList;
//    }
//
//    public List<Comments> getCommentsList() {
//        return commentsList;
//    }
//
//    public void setCommentsList(List<Comments> commentsList) {
//        this.commentsList = commentsList;
//    }

    @Override
    public String toString() {
        return "Videos{" +
                "videoId=" + videoId +
                ", videoTitle='" + videoTitle + '\'' +
                ", videoDescription='" + videoDescription + '\'' +
                ", videoURL='" + videoURL + '\'' +

                ", videoUploadedAt='" + videoUploadedAt + '\'' +
                ", user=" + user +
                '}';
    }
}


