package com.zee.demo.FinalProject.Controller;

import com.zee.demo.FinalProject.Entity.Videos;
import com.zee.demo.FinalProject.Service.VideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController
public class VideoController
{
    @Autowired
    VideoService VS;

    @PostMapping("/api/admin/videos/{userid}")
    public void uploadVideo(@RequestBody Videos V, @PathVariable("userid") int id)
    {
        VS.uploadVideoService(V,id);
    }

    @GetMapping("/api/videos/{videoId}")
    public ResponseEntity<Videos> getVideo(@PathVariable("videoId") int id) {
        Videos V = VS.getVideoService(id);
        return new ResponseEntity<>(V, HttpStatus.OK);
    }

    @GetMapping("/api/videos")
    public ResponseEntity<List<Videos>> getVideos()
    {
        List<Videos> list = VS.getVideosService();
        for(Videos v : list)
        {
            System.out.println(v.toString());
//            v.getVideoId();
//            v.getVideoDescription();
        }
//        System.out.println(list.size());
        return new ResponseEntity<List<Videos>>(list,HttpStatus.OK);
    }

    @GetMapping("api/genres/{genreCode}/videos")
    public ResponseEntity<List<Integer>> getVideoWithSpecificGenre(@PathVariable("genreCode") int genrecode)
    {
        List<Integer> list = VS.getVideoWithSpecificGenreService(genrecode);
        return new ResponseEntity<>(list,HttpStatus.OK);

    }

    @PutMapping("api/admin/videos/{videoId}")
    public ResponseEntity<String> updateVideo(@RequestBody Videos V,@PathVariable("videoId") int videoid)
    {
        String message = VS.updateVideoService(V,videoid);
        return new ResponseEntity<>(message,HttpStatus.OK);
    }

    @DeleteMapping("api/admin/videos/{videoId}")
    public ResponseEntity<String> deleteVideo(@PathVariable("videoId") int videoid)
    {
        String message = VS.deleteVideoService(videoid);
        return new ResponseEntity<>(message,HttpStatus.OK);
    }
}
