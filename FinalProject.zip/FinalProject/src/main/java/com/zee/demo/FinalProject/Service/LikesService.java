package com.zee.demo.FinalProject.Service;

import com.zee.demo.FinalProject.Entity.Likes;
import com.zee.demo.FinalProject.Entity.Users;
import com.zee.demo.FinalProject.Entity.Videos;
import com.zee.demo.FinalProject.Kafka.Publisher;
import com.zee.demo.FinalProject.Repository.LikesRepository;
import com.zee.demo.FinalProject.Repository.UsersRepository;
import com.zee.demo.FinalProject.Repository.VideosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;
@Service
public class LikesService {

    @Autowired
    LikesRepository LR;

    @Autowired
    UsersRepository UR;

    @Autowired
    VideosRepository VR;

    @Autowired
    Publisher P;
    public List<Likes> getLikesByUserService(int userid)
    {
        System.out.println(UR.findById(userid).get());
        List<Likes> list = LR.findByUser(UR.findById(userid).get());
        P.sendLikesInfo("Count of likes by user " +  userid + " : " + list.size());
        return list;
    }

    public List<Likes> getLikesOfVideosService(int videoid)
    {
        List<Likes> list =LR.findByVideos(VR.findById(videoid).get());
        P.sendLikesInfo("Count of likes to video " +  videoid + " : " + list.size());
        return list;
    }

    public void likeByUserService(Likes like, int userid)
    {
        Users U = UR.findById(userid).get();
        like.setUser(U);
        int id = (like.getVideos()).getVideoId();
        Videos V= VR.findById(id).get();
        like.setVideos(V);
        P.sendLikesInfo("User " +  userid + " liked the video " + V.getVideoId());
        LR.save(like);
    }

    public void deleteLikeService(int userid,int videoid)
    {
        Users U = UR.findById(userid).get();
        Videos V = VR.findById(videoid).get();
        List<Likes> l1 = LR.findByUser(U);
        List<Likes> l2 = LR.findByVideos(V);
        for(Likes l : l1)
        {
            if(l2.contains(l))
            {
                LR.deleteById(l.getLikeId());
                P.sendLikesInfo("User " +  userid + " unliked the video " + videoid);
            }
        }
    }
}
