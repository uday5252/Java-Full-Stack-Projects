package com.zee.demo.FinalProject.Kafka;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;

@Configuration
public class KafkaTopics {

    @Bean
    public NewTopic LikesTopic() {
        return TopicBuilder.name("likeTopic").build();
    }
    @Bean
    public NewTopic CommentsTopic()
    {
        return TopicBuilder.name("commentTopic").build();
    }

    @Bean
    public NewTopic VideosTopic()
    {
        return TopicBuilder.name("videoTopic").build();
    }

    @Bean
    public NewTopic GenresTopic()
    {
        return TopicBuilder.name("genreTopic").build();
    }
}
