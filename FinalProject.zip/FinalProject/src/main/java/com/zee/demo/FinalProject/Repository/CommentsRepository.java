package com.zee.demo.FinalProject.Repository;

import com.zee.demo.FinalProject.Entity.Comments;
import com.zee.demo.FinalProject.Entity.Likes;
import com.zee.demo.FinalProject.Entity.Users;
import com.zee.demo.FinalProject.Entity.Videos;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CommentsRepository extends JpaRepository<Comments,Integer> {
    List<Comments> findByUser(Users user);
    List<Comments> findByVideos(Videos video);
}
