package com.zee.demo.FinalProject.Service;

import com.zee.demo.FinalProject.Entity.Users;
import com.zee.demo.FinalProject.Repository.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class UserService
{

    @Autowired
    UsersRepository UR;

    public UserService(UsersRepository UR)
    {
        this.UR = UR;
    }

    public List<Users> getUsersService() {
        return UR.findAll();
    }

    public void addUserService(Users u) {

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        u.setUserCreatedAt(dtf.format(now));
        u.setUserUpdatedAt(dtf.format(now));
        UR.save(u);
    }

    public void deleteUserService(int id)
    {
        UR.deleteById(id);
    }
}
