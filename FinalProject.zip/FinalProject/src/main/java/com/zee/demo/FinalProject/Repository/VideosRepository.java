package com.zee.demo.FinalProject.Repository;

import com.zee.demo.FinalProject.Entity.Videos;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VideosRepository extends JpaRepository<Videos,Integer>
{


}
