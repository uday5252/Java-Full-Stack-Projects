package com.zee.demo.FinalProject.Entity;

import jakarta.persistence.*;

@Entity
public class Genres {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int genreId;

    private int genreCode;
    private String genreName;
    private String genreDescription;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "videoId")
    private Videos video;

    public String getGenreDescription() {
        return genreDescription;
    }

    public void setGenreDescription(String genreDescription) {
        this.genreDescription = genreDescription;
    }

    public String getGenreName() {
        return genreName;
    }

    public void setGenreName(String genreName) {
        this.genreName = genreName;
    }

    public int getGenreCode() {
        return genreCode;
    }

    public void setGenreCode(int genreCode) {
        this.genreCode = genreCode;
    }

    public void setVideo(Videos video) {
        this.video = video;
    }

    public Videos getVideo() {
        return video;
    }
}
