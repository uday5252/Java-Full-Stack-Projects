package com.zee.demo.FinalProject.Controller;

import com.zee.demo.FinalProject.Entity.Users;
import com.zee.demo.FinalProject.Service.UserService;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
@RestController
public class UserController {

    @Autowired
    UserService US;
    @GetMapping("/api/user")
    public ResponseEntity<List<Users>> getUsers()
    {
        List<Users> usersList =  US.getUsersService();
        System.out.println(usersList);
        return new ResponseEntity<>(usersList, HttpStatus.OK);
    }

    @PostMapping("/api/user")
    public void addUser(@RequestBody Users U)
    {
        US.addUserService(U);
    }

    @DeleteMapping("/api/user/{userId}")
    public void deleteUser(@PathVariable("userId") int Id)
    {
        US.deleteUserService(Id);
    }
}
