package com.zee.demo.FinalProject.Controller;

import com.zee.demo.FinalProject.Entity.Genres;
import com.zee.demo.FinalProject.Service.GenreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
public class GenreController
{
    @Autowired
    GenreService GS;

    @GetMapping("/api/genres")
    public void getAllGenres()
    {
        List<Genres> genrelist = GS.getAllGenresService();
        System.out.println(genrelist);
    }

    @PostMapping("/api/user/{genres}")
    public void addGenre(@PathVariable("genres") String genreType,@RequestBody Genres G)
    {
        GS.addGenreService(G,genreType);
    }


    @PutMapping("api/user/genres/{genreId}")
    public void updateGenre(@RequestBody Genres G,@PathVariable("genreId") int Id)
    {
        GS.updateGenreService(G,Id);

    }

    @DeleteMapping("api/user/genres/{genreId}")
    public void deleteGenre(@PathVariable("genreId") int Id)
    {
        GS.deleteGenreService(Id);
    }




}
