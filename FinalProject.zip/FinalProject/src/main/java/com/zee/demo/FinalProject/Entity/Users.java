package com.zee.demo.FinalProject.Entity;

import jakarta.persistence.*;
import java.util.*;
@Entity
public class Users
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int userId;
    private String userName;
    private String userPassword;
    private String userEmail;
    private String userCreatedAt;
    private String userUpdatedAt;

    // if we put one to many here the issue causes is u can be able to get the data because of the cyclic loops forming in.
//    @OneToMany(mappedBy = "user",cascade = CascadeType.ALL)
////    @JoinColumn(name = "videoUploadedBy", referencedColumnName = "userId")
//    private List<Videos> videosList= new ArrayList<>();

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getUserEmail() {
        return userEmail;
    }
//    public List<Videos> getVideosList(){
//        return videosList;
//    }
//
//    public void setVideosList(List<Videos> videosList) {
//        this.videosList = videosList;
//    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserCreatedAt() {
        return userCreatedAt;
    }

    public void setUserCreatedAt(String userCreatedAt) {
        this.userCreatedAt = userCreatedAt;
    }

    public String getUserUpdatedAt() {
        return userUpdatedAt;
    }

    public void setUserUpdatedAt(String userUpdatedAt) {
        this.userUpdatedAt = userUpdatedAt;
    }

}
