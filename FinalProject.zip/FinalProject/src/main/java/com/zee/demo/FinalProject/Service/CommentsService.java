package com.zee.demo.FinalProject.Service;

import com.zee.demo.FinalProject.Entity.Comments;
import com.zee.demo.FinalProject.Entity.Likes;
import com.zee.demo.FinalProject.Entity.Users;
import com.zee.demo.FinalProject.Entity.Videos;
import com.zee.demo.FinalProject.Kafka.Publisher;
import com.zee.demo.FinalProject.Repository.CommentsRepository;
import com.zee.demo.FinalProject.Repository.LikesRepository;
import com.zee.demo.FinalProject.Repository.UsersRepository;
import com.zee.demo.FinalProject.Repository.VideosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CommentsService
{
    @Autowired
    CommentsRepository CR;
    @Autowired
    UsersRepository UR;

    @Autowired
    VideosRepository VR;

    @Autowired
    Publisher P;

    public List<Comments> getCommentsByUserService(int userid)
    {
        System.out.println(UR.findById(userid).get());
        List<Comments> list = CR.findByUser(UR.findById(userid).get());
        P.sendCommentsInfo("Count of comments by user " +  userid + " : " + list.size());
        return list;

    }

    public List<Comments> getCommentsOfVideosServie(int videoid)
    {
        List<Comments> list =CR.findByVideos(VR.findById(videoid).get());
        P.sendCommentsInfo("Count of comments to video " +  videoid + " : " + list.size());
        return list;

    }

    public void commentByUserService(Comments comment, int userid)
    {
        Users U = UR.findById(userid).get();
        comment.setUser(U);
        int id = (comment.getVideos()).getVideoId();
        Videos V= VR.findById(id).get();
        comment.setVideos(V);
        CR.save(comment);
        P.sendCommentsInfo("User " +  userid + " commented on the video " + V.getVideoId());
    }

    public void deleteCommentService(int userid, int videoid)
    {
        Users U = UR.findById(userid).get();
        Videos V = VR.findById(videoid).get();
        List<Comments> l1 = CR.findByUser(U);
        List<Comments> l2 = CR.findByVideos(V);
        for(Comments l : l1)
        {
            if(l2.contains(l))
            {
                CR.deleteById(l.getCommentId());
                P.sendCommentsInfo("User with id " +  userid + " deleted the comment on video with id " + videoid);
            }
        }

    }
}







