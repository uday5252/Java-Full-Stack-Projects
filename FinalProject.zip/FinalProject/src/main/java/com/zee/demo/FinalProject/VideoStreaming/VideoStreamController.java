package com.zee.demo.FinalProject.VideoStreaming;

import com.zee.demo.FinalProject.Entity.Videos;
import com.zee.demo.FinalProject.Repository.VideosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


@Controller
public class VideoStreamController
{
    @Autowired
    VideosRepository VR;
    @GetMapping("/streamvideo/{videoId}")
    public String streamVideo(@PathVariable("videoId") int vid, Model m)
    {
        Videos V =  VR.findById(vid).get();
        String url = V.getVideoURL();
        m.addAttribute("link",url);
        return "videostreamPage";
    }
}
