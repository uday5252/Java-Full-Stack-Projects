package com.zee.demo.FinalProject.Entity;

import jakarta.persistence.*;

@Entity
public class Likes
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int likeId;
    @ManyToOne()
    @JoinColumn(name = "userId")
    private Users user;

    @ManyToOne()
    @JoinColumn(name = "videoId")
    private  Videos videos;

    public int getLikeId() {
        return likeId;
    }

    public Users getUser() {
        return user;
    }

    public void setUser(Users user) {
        this.user = user;
    }

    public Videos getVideos() {
        return videos;
    }

    public void setVideos(Videos videos) {
        this.videos = videos;
    }
}
