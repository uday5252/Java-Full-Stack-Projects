package com.zee.demo.FinalProject.Service;

import com.zee.demo.FinalProject.Entity.Genres;
import com.zee.demo.FinalProject.Entity.Users;
import com.zee.demo.FinalProject.Entity.Videos;
import com.zee.demo.FinalProject.Kafka.Publisher;
import com.zee.demo.FinalProject.Repository.GenresRepository;
import com.zee.demo.FinalProject.Repository.UsersRepository;
import com.zee.demo.FinalProject.Repository.VideosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class VideoService {

    @Autowired
    Publisher P;

    @Autowired
    VideosRepository VR;
    @Autowired
    UsersRepository UR;
    @Autowired
    GenresRepository GR;

    public void uploadVideoService(Videos v, int id) {
        Users u = UR.findById(id).get();
        v.setUser(u);
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        v.setVideoUploadedAt(dtf.format(now));
        List<Genres> s = v.getGenresSet();
        for (Genres g : s) {
            String genreName = g.getGenreName();
            List<Genres> l = GR.findByGenreName(genreName);
            Genres obj = l.get(0);
            g.setGenreDescription(obj.getGenreDescription());
            g.setGenreCode(obj.getGenreCode());
            g.setVideo(v);
            GR.save(g);
        }
        VR.save(v);
        P.sendVideosInfo("Video with id " + v.getVideoId() +" uploaded by user " + id);
    }

    public Videos getVideoService(int id) {
        Videos V = VR.findById(id).get();
        return V;
    }

    public List<Videos> getVideosService() {
        List<Videos> list = VR.findAll();
        P.sendVideosInfo("Total Count of videos: " + list.size());
        return list;
    }

    public List<Integer> getVideoWithSpecificGenreService(int genreCode) {
        List<Genres> genreList = GR.findByGenreCode(genreCode);
        System.out.println(genreList.size());
        List<Integer> videoList = new ArrayList<>();
        for (Genres G : genreList) {
            Videos v = G.getVideo();
            if (v != null) {
                videoList.add(v.getVideoId());
            }
        }
        return videoList;
    }

    public String updateVideoService (Videos V,int videoid)
    {
        Videos obj = VR.findById(videoid).get();
        obj.setVideoUploadedAt((V.getVideoUploadedAt() != null) ? V.getVideoUploadedAt() : obj.getVideoUploadedAt());
        obj.setUser((V.getUser() != null) ? V.getUser() : obj.getUser());
        obj.setVideoURL((V.getVideoURL() != null) ? V.getVideoURL() : obj.getVideoURL());
        obj.setVideoTitle((V.getVideoTitle() != null) ? V.getVideoTitle() : obj.getVideoTitle());
        obj.setVideoDescription((V.getVideoDescription() != null) ? V.getVideoDescription() : obj.getVideoDescription());
//       obj.setGenresSet((V.getGenresSet()!=null) ? V.getGenresSet() : obj.getGenresSet());
        VR.save(obj);
        P.sendVideosInfo("Video updated with ID: " + videoid);
        return "Updated!";
    }

    public String deleteVideoService ( int videoid)
    {
        VR.deleteById(videoid);
        P.sendVideosInfo("Video deleted with ID: " + videoid);
        return ("Video deleted with ID: " + videoid);
    }
}

/*
genreCode":"2",
      "genreName": "Action",
      "genreDescription": "This is action"
 */
