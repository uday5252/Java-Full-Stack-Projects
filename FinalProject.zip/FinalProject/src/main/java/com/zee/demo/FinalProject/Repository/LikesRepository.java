package com.zee.demo.FinalProject.Repository;

import com.zee.demo.FinalProject.Entity.Likes;
import com.zee.demo.FinalProject.Entity.Users;
import com.zee.demo.FinalProject.Entity.Videos;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;

public interface LikesRepository extends JpaRepository<Likes,Integer>
{
    List<Likes> findByUser(Users user);
    List<Likes> findByVideos(Videos video);
}
